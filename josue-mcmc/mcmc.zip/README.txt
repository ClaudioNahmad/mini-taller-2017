Este paquete contiene los siguientes archivos:

taller.py : El programa del método de Metropolis que desarrollamos en el taller.

distance.py : Un programa basado en este programa inicial pero con algunas funcionalidades extra inclullendo un algoritmo para calcular y graficar los contornos de confianza de los parámetros.

Saludos

Josué De Santiago 2017
