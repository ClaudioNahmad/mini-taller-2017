var searchData=
[
  ['y',['y',['../perturbations_8h.html#af05dcb0f0d9c579ef53ef0d6c65f2709',1,'perturb_vector']]],
  ['yhe',['YHe',['../thermodynamics_8h.html#a5659de2c81941b7a400fd7e7ea3c313d',1,'thermo::YHe()'],['../thermodynamics_8h.html#ab03e0d029be17effdb0a1b9a44ed35df',1,'recombination::YHe()']]]
];
