var searchData=
[
  ['class_3a_20cosmic_20linear_20anisotropy_20solving_20system',['CLASS: Cosmic Linear Anisotropy Solving System',['../index.html',1,'']]],
  ['class_20overview_20_28architecture_2c_20input_2foutput_2c_20general_20principles_29',['CLASS overview (architecture, input/output, general principles)',['../md_chap3.html',1,'']]]
];
