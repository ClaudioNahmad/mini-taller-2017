var background_8c =
[
    [ "background_at_tau", "background_8c.html#ac47004414b208d36153f35d8465cace2", null ],
    [ "background_tau_of_z", "background_8c.html#a868e85eefe464a31b25639170ff9550c", null ],
    [ "background_functions", "background_8c.html#a302eb502773905601fa9b6936840682a", null ],
    [ "background_w_fld", "background_8c.html#a488d6a6f015cec7a4eae21556e2298ca", null ],
    [ "background_init", "background_8c.html#afeb0656453b92be39c60fb3fb1abd910", null ],
    [ "background_free", "background_8c.html#a5b0d8db279856b3c96aba08c83aa19d6", null ],
    [ "background_free_input", "background_8c.html#a61601a17447fc6a806921680d2e52c8f", null ],
    [ "background_indices", "background_8c.html#a8934d2c903bb4c78b1b6a33a8c56e293", null ],
    [ "background_ncdm_distribution", "background_8c.html#a3f8ea8dea94f63d01aa8fdcc3e0fb71a", null ],
    [ "background_ncdm_test_function", "background_8c.html#a59fa78f56e5b35c640712db6a7941a82", null ],
    [ "background_ncdm_init", "background_8c.html#a7f380a260c9369b66422a58391797728", null ],
    [ "background_ncdm_momenta", "background_8c.html#afc47d7f15b3ff372df079890efcc6eb6", null ],
    [ "background_ncdm_M_from_Omega", "background_8c.html#a5cc3564dbb251914c77d44f4990b21b9", null ],
    [ "background_solve", "background_8c.html#aeb523f9c8e728f79e9b431d2020faa41", null ],
    [ "background_initial_conditions", "background_8c.html#ad2dc56f010363d90bb1ad8447a32baf9", null ],
    [ "background_output_titles", "background_8c.html#a038afb8102e9f45af7524a59011c371f", null ],
    [ "background_output_data", "background_8c.html#a0ff17dd11a557890bcd66920397828ad", null ],
    [ "background_derivs", "background_8c.html#a7125aa3a44915ea6d0cca6f37613421a", null ],
    [ "V_e_scf", "background_8c.html#a0b67501d55c3db17771981743e2309e2", null ],
    [ "V_p_scf", "background_8c.html#a9bd1bb8603145f86e8c57ad64a709931", null ],
    [ "V_scf", "background_8c.html#aea9a32ebd60cc65e848e38cdd3ea6df5", null ]
];