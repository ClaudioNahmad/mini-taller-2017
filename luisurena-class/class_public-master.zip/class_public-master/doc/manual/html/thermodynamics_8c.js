var thermodynamics_8c =
[
    [ "thermodynamics_at_z", "thermodynamics_8c.html#a5763e8991ba30efe92c3007d1abfee95", null ],
    [ "thermodynamics_init", "thermodynamics_8c.html#a1acbfae38edb0c73d8991645f89b2d13", null ],
    [ "thermodynamics_free", "thermodynamics_8c.html#a689045596045ab02bb1853298d81f634", null ],
    [ "thermodynamics_indices", "thermodynamics_8c.html#a8fff80fda27805f33d1f3deaf9f90cce", null ],
    [ "thermodynamics_helium_from_bbn", "thermodynamics_8c.html#aa99e8a0f968b10a07df134c51011ed2e", null ],
    [ "thermodynamics_onthespot_energy_injection", "thermodynamics_8c.html#a7f1a04c6e4b080dbbe2855969e16eb25", null ],
    [ "thermodynamics_energy_injection", "thermodynamics_8c.html#ad83c9423d4031f0f3797afb6ff2e33b5", null ],
    [ "thermodynamics_reionization_function", "thermodynamics_8c.html#a2c452e9b63299d65eaabe2065bfbb8a8", null ],
    [ "thermodynamics_get_xe_before_reionization", "thermodynamics_8c.html#a81120dad31dd155c4c3eaca36da53080", null ],
    [ "thermodynamics_reionization", "thermodynamics_8c.html#aa8e6b48cadc0a989b729fa624e1d61b3", null ],
    [ "thermodynamics_reionization_sample", "thermodynamics_8c.html#a056862f1b2d37b8408ab7fdde116968f", null ],
    [ "thermodynamics_recombination", "thermodynamics_8c.html#a13696727ba92af10edfed3ebf8c43a8a", null ],
    [ "thermodynamics_recombination_with_hyrec", "thermodynamics_8c.html#a3bddca88ed8e4de96ef783710739b2e6", null ],
    [ "thermodynamics_recombination_with_recfast", "thermodynamics_8c.html#ab7d2c22e2a933156c291bfa467731ab2", null ],
    [ "thermodynamics_derivs_with_recfast", "thermodynamics_8c.html#a00dc65dc088eabe075227c673f091297", null ],
    [ "thermodynamics_merge_reco_and_reio", "thermodynamics_8c.html#a49f9b949c30411585549b523d2033089", null ],
    [ "thermodynamics_output_titles", "thermodynamics_8c.html#a4f8b2bc131699db3ff7e2b9c14dfe940", null ]
];