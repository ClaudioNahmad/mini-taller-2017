var structnonlinear =
[
    [ "method", "structnonlinear.html#aa5256a476f6fa766b8977272715be21a", null ],
    [ "k_size", "structnonlinear.html#a5337c7a8ffea7bb7f178d6bad11b5622", null ],
    [ "k", "structnonlinear.html#a6d371ac0fc8dfdef575a5751afd44565", null ],
    [ "tau_size", "structnonlinear.html#a65b7e2e5ec57b04277e3797c6953e6ba", null ],
    [ "tau", "structnonlinear.html#a58f60e148801438e7291a5ca86dbf088", null ],
    [ "nl_corr_density", "structnonlinear.html#a774d3d64ba57a3441c012096f1af7147", null ],
    [ "k_nl", "structnonlinear.html#a0cf43f23da9a66bad019e2cdc8c7128e", null ],
    [ "nonlinear_verbose", "structnonlinear.html#a793810d8ed0e8a951293d0d4b1475c46", null ],
    [ "error_message", "structnonlinear.html#aea8dcc26882acb6c85a66e1aabcbc6c9", null ]
];